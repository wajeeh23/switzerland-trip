/*
  ملف جافاسكربت لتطبيق رحلة سويسرا
  ينفذ منطق تحميل البرنامج، إدارة تسجيل الدخول، عرض المساعد الذكي
  وتنفيذ الإشعارات والبحث عن المطاعم والطقس.
*/

// متغيرات عامة
let scheduleData = [];
let userInfo = null;
let notificationTimers = [];
let sentNotifications = new Set();

// تحميل البيانات عند جاهزية الصفحة
document.addEventListener('DOMContentLoaded', () => {
  // تحميل جدول الرحلة
  loadSchedule();
  // التنقل بين الأقسام
  initNavigation();
  // معالجة تسجيل الدخول
  initLogin();
});

/**
 * تحميل جدول الرحلة من ملف JSON
 */
function loadSchedule() {
  // محاولة قراءة بيانات الجدول من عنصر مخفي في الصفحة
  const embedded = document.getElementById('schedule-data');
  if (embedded && embedded.textContent.trim().startsWith('[')) {
    try {
      scheduleData = JSON.parse(embedded.textContent);
      renderProgramList();
      populateCitySelects();
      checkClosing();
      return;
    } catch (e) {
      console.warn('تعذر قراءة بيانات الجدول المضمنة:', e);
    }
  }
  // في حال عدم وجود عنصر البيانات أو فشل التحليل جرب التحميل عبر fetch
  fetch('schedule.json')
    .then((res) => res.json())
    .then((data) => {
      scheduleData = data;
      renderProgramList();
      populateCitySelects();
      checkClosing();
    })
    .catch((err) => {
      console.error('خطأ في تحميل جدول الرحلة:', err);
    });
}

/**
 * إنشاء عناصر البرنامج وعرضها في الواجهة
 */
function renderProgramList() {
  const listContainer = document.getElementById('program-list');
  listContainer.innerHTML = '';
  scheduleData.forEach((entry, index) => {
    const item = document.createElement('div');
    item.className = 'program-item';
    // عنوان
    const title = document.createElement('div');
    title.className = 'title';
    title.textContent = entry.title;
    // تاريخ
    const dateDiv = document.createElement('div');
    dateDiv.className = 'date';
    dateDiv.textContent = formatDateDisplay(entry.date);
    // تفاصيل مخفية
    const details = document.createElement('div');
    details.className = 'details';
    // استبدل الأسطر الجديدة بعلامات <br>
    details.innerHTML = entry.description.replace(/\n/g, '<br>');
    item.appendChild(title);
    item.appendChild(dateDiv);
    item.appendChild(details);
    // عند النقر إظهار/إخفاء التفاصيل
    item.addEventListener('click', () => {
      details.style.display = details.style.display === 'block' ? 'none' : 'block';
    });
    listContainer.appendChild(item);
  });
}

/**
 * إعداد أزرار التنقل لتبديل الأقسام
 */
function initNavigation() {
  const navButtons = document.querySelectorAll('.nav-btn');
  navButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      // إزالة active من جميع الأزرار
      navButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      const sectionId = btn.getAttribute('data-section');
      document.querySelectorAll('.section').forEach((sec) => {
        sec.style.display = sec.id === sectionId ? 'block' : 'none';
      });
    });
  });
}

/**
 * إعداد واجهة تسجيل الدخول وتخزين معلومات المستخدم
 */
function initLogin() {
  // تحقق مما إذا كانت بيانات المستخدم موجودة مسبقاً
  const saved = localStorage.getItem('swiss_trip_user');
  if (saved) {
    try {
      userInfo = JSON.parse(saved);
    } catch {
      userInfo = null;
    }
  }
  const loginOverlay = document.getElementById('login-container');
  const loginBtn = document.getElementById('login-btn');
  if (userInfo) {
    // إخفاء نموذج الدخول وبدء التنبيهات
    loginOverlay.style.display = 'none';
    startNotifications();
  } else {
    loginOverlay.style.display = 'flex';
  }
  loginBtn.addEventListener('click', () => {
    const nameVal = document.getElementById('name').value.trim();
    const emailVal = document.getElementById('email').value.trim();
    const phoneVal = document.getElementById('phone').value.trim();
    if (!nameVal || !emailVal || !phoneVal) {
      alert('يرجى تعبئة جميع الحقول');
      return;
    }
    userInfo = { name: nameVal, email: emailVal, phone: phoneVal };
    localStorage.setItem('swiss_trip_user', JSON.stringify(userInfo));
    loginOverlay.style.display = 'none';
    startNotifications();
  });
}

/**
 * التحقق من تاريخ الإغلاق: إذا مر 5 أيام على آخر يوم في الجدول يتم إغلاق الموقع
 */
function checkClosing() {
  if (!scheduleData || scheduleData.length === 0) return;
  const lastEntry = scheduleData[scheduleData.length - 1];
  const parts = lastEntry.date.split('.');
  // نفترض أن السنة 2025 لأن التواريخ في الملف تعود لعام 2025
  const tripEnd = new Date(2025, parseInt(parts[1], 10) - 1, parseInt(parts[0], 10));
  // إضافة خمسة أيام
  const closingDate = new Date(tripEnd.getTime() + 5 * 24 * 60 * 60 * 1000);
  const now = new Date();
  const closed = now > closingDate;
  const closedDiv = document.getElementById('closed-message');
  if (closed) {
    // عرض رسالة الإغلاق وإخفاء بقية المحتوى
    closedDiv.style.display = 'flex';
    document.getElementById('navigation').style.display = 'none';
    document.getElementById('content').style.display = 'none';
    document.getElementById('main-header').style.display = 'none';
    // إخفاء نموذج الدخول في حال وجوده
    document.getElementById('login-container').style.display = 'none';
  } else {
    closedDiv.style.display = 'none';
  }
}

/**
 * تشغيل نظام التنبيهات بناءً على جدول الرحلة
 */
function startNotifications() {
  if (!scheduleData || scheduleData.length === 0) return;
  // بناء قائمة أوقات لكل يوم
  const events = [];
  scheduleData.forEach((entry) => {
    // تحضير التاريخ بصيغة YYYY-MM-DD
    const [day, month] = entry.date.split('.');
    const eventDate = new Date(2025, parseInt(month) - 1, parseInt(day));
    // إضافة إشعار الساعة السادسة صباحاً لإرسال برنامج اليوم
    events.push({ datetime: new Date(eventDate.getFullYear(), eventDate.getMonth(), eventDate.getDate(), 6, 0), type: 'morning', entry: entry });
    // استخراج الأوقات من الوصف والعنوان
    const times = [];
    const combined = entry.title + ' ' + entry.description;
    const timePattern = /(\d{1,2}:\d{2})/g;
    let match;
    while ((match = timePattern.exec(combined))) {
      times.push(match[1]);
    }
    // إزالة التكرار وترتيبها
    const uniqueTimes = Array.from(new Set(times)).sort((a, b) => {
      const [ah, am] = a.split(':').map((x) => parseInt(x));
      const [bh, bm] = b.split(':').map((x) => parseInt(x));
      return ah === bh ? am - bm : ah - bh;
    });
    // فلترة الأوقات غير المنطقية (مثل مدة 1:10) بحيث تكون بين الخامسة صباحاً والحادية عشرة مساءً
    const filteredTimes = uniqueTimes.filter((t) => {
      const [h, m] = t.split(':').map((x) => parseInt(x));
      return h >= 5 && h <= 23;
    });
    filteredTimes.forEach((t, idx) => {
      const [h, m] = t.split(':').map((x) => parseInt(x));
      const dt = new Date(eventDate.getFullYear(), eventDate.getMonth(), eventDate.getDate(), h, m);
      events.push({ datetime: dt, type: 'event', entry: entry, timeIndex: idx, times: filteredTimes });
    });
  });
  // ترتيب الأحداث بحسب الوقت
  events.sort((a, b) => a.datetime - b.datetime);
  // مؤقت للتحقق كل دقيقة
  setInterval(() => {
    const now = new Date();
    events.forEach((ev) => {
      // مقارنة الوقت الحالي مع وقت الحدث (دقيقة واحدة دقة)
      if (
        now.getFullYear() === ev.datetime.getFullYear() &&
        now.getMonth() === ev.datetime.getMonth() &&
        now.getDate() === ev.datetime.getDate() &&
        now.getHours() === ev.datetime.getHours() &&
        now.getMinutes() === ev.datetime.getMinutes()
      ) {
        const key = ev.datetime.toISOString();
        if (!sentNotifications.has(key)) {
          sentNotifications.add(key);
          if (ev.type === 'morning') {
            sendMorningNotification(ev.entry);
          } else if (ev.type === 'event') {
            const nextTime = ev.times[ev.timeIndex + 1] || null;
            sendEventNotification(ev.entry, ev.times[ev.timeIndex], nextTime);
          }
        }
      }
    });
  }, 60000);
}

/**
 * إرسال برنامج اليوم الساعة السادسة صباحاً
 */
function sendMorningNotification(entry) {
  const msg = `صباح الخير ${userInfo?.name || ''}!\nاليوم (${formatDateDisplay(entry.date)}) يتضمن: ${entry.title}.\nانقر لعرض التفاصيل في التطبيق.`;
  displayNotification(msg);
}

/**
 * إرسال تنبيه بعد حدث محدد مع إعلام المستخدم بوجهته التالية
 */
function sendEventNotification(entry, time, nextTime) {
  let msg = `تذكير بحدث الساعة ${time} في يوم ${formatDateDisplay(entry.date)}.\n${entry.title}`;
  if (nextTime) {
    msg += `\nوجهتك التالية عند الساعة ${nextTime}.`;
  } else {
    msg += '\nانتهى برنامج اليوم. استمتع بوقتك!';
  }
  displayNotification(msg);
}

/**
 * عرض التنبيهات للمستخدم – حالياً نستخدم alert ويمكن تحسينه لاحقاً
 */
function displayNotification(message) {
  // يمكنك تغيير هذا لتنفيذ إرسال بريد حقيقي أو رسالة نصية
  // في هذا التطبيق، سنقوم بعرض تنبيه عبر alert بالإضافة لفتح رابط
  // لإرسال بريد إلكتروني ورسالة نصية قصيرة للمستخدم بناءً على بياناته.
  alert(message);
  if (userInfo) {
    // إنشاء رابط mailto لإرسال البريد الإلكتروني
    const subject = encodeURIComponent('تذكير بالبرنامج');
    const body = encodeURIComponent(message);
    const mailtoUrl = `mailto:${encodeURIComponent(userInfo.email)}?subject=${subject}&body=${body}`;
    // فتح نافذة البريد (لن يُرسل البريد تلقائياً إنما يفتح مسودة)
    window.open(mailtoUrl, '_blank');
    // إنشاء رابط sms لإرسال الرسائل النصية في الهواتف المدعومة
    const smsUrl = `sms:${encodeURIComponent(userInfo.phone)}?body=${body}`;
    window.open(smsUrl, '_blank');
  }
  // تسجيل في وحدة التحكم للمطور
  console.log('Notification:', message);
}

/**
 * تحويل تاريخ dd.mm إلى نص عربي جميل
 */
function formatDateDisplay(dateStr) {
  const [d, m] = dateStr.split('.');
  return `${d}/${m}/2025`;
}

/**
 * إنشاء قائمة بالمدن الفريدة من الجدول وملء القوائم المنسدلة
 */
function populateCitySelects() {
  const locations = new Set();
  scheduleData.forEach((entry) => {
    // استخراج كلمات من العنوان التي تبدو كأسماء أماكن
    const parts = entry.title.split(/\s+/);
    parts.forEach((p) => {
      // تجاهل الكلمات القصيرة والأرقام
      if (/^[A-Za-zא-ת]+$/.test(p) && p.length > 3) {
        locations.add(p.replace(/\W+/g, ''));
      }
    });
  });
  const cityList = Array.from(locations);
  // ملء قائمة الطقس
  const weatherSelect = document.getElementById('weather-city');
  cityList.forEach((city) => {
    const opt = document.createElement('option');
    opt.value = city;
    opt.textContent = city;
    weatherSelect.appendChild(opt);
  });
  // ملء قائمة المطاعم الاحتياطية
  const citySelect = document.getElementById('city-select');
  cityList.forEach((city) => {
    const opt = document.createElement('option');
    opt.value = city;
    opt.textContent = city;
    citySelect.appendChild(opt);
  });
  // إعداد زر الطقس
  document.getElementById('weather-fetch').addEventListener('click', () => {
    const city = weatherSelect.value;
    if (!city) {
      alert('يرجى اختيار موقع');
      return;
    }
    fetchWeather(city);
  });
  // إعداد التحكم في المطاعم
  document.getElementById('meal-type').addEventListener('change', (e) => {
    const val = e.target.value;
    const catDiv = document.getElementById('category-buttons');
    if (val) {
      catDiv.style.display = 'block';
    } else {
      catDiv.style.display = 'none';
      document.getElementById('location-select').style.display = 'none';
    }
  });
  document.querySelectorAll('.cat-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const meal = document.getElementById('meal-type').value;
      const cat = btn.getAttribute('data-cat');
      // محاولة الحصول على الموقع الحالي
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const lat = pos.coords.latitude.toFixed(4);
            const lon = pos.coords.longitude.toFixed(4);
            openRestaurantSearch(meal, cat, `${lat},${lon}`);
          },
          (err) => {
            console.warn('تعذر تحديد الموقع:', err);
            // إظهار اختيار المدينة
            document.getElementById('location-select').style.display = 'block';
            document.getElementById('city-select').onchange = function () {
              const city = this.value;
              if (city) {
                openRestaurantSearch(meal, cat, city);
              }
            };
          }
        );
      } else {
        // عدم توفر geolocation
        document.getElementById('location-select').style.display = 'block';
        document.getElementById('city-select').onchange = function () {
          const city = this.value;
          if (city) {
            openRestaurantSearch(meal, cat, city);
          }
        };
      }
    });
  });
  // إعداد المساعد الذكي
  initAssistant();
}

/**
 * فتح بحث المطاعم في نافذة جديدة حسب الوجبة والفئة والموقع
 */
function openRestaurantSearch(meal, cat, location) {
  // تحويل أنواع الوجبات والفئات إلى كلمات مفتاحية باللغة الإنجليزية
  const mealMap = {
    breakfast: 'breakfast',
    snacks: 'snack',
    lunch: 'lunch',
    dinner: 'dinner'
  };
  const catMap = {
    popular: 'casual',
    mid: 'midrange',
    luxury: 'fine dining'
  };
  const query = `${mealMap[meal]} ${catMap[cat]} restaurants near ${location}`;
  const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
  window.open(url, '_blank');
}

/**
 * جلب بيانات الطقس من wttr.in وعرضها للمستخدم
 */
function fetchWeather(city) {
  const resultDiv = document.getElementById('weather-result');
  resultDiv.textContent = 'جارٍ جلب بيانات الطقس...';
  fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`)
    .then((res) => res.json())
    .then((data) => {
      // الحصول على الحالة الحالية ومتوسط درجة الحرارة لليوم
      const current = data.current_condition && data.current_condition[0];
      const today = data.weather && data.weather[0];
      let message = '';
      if (current) {
        message += `الطقس الحالي: ${current.weatherDesc[0].value}، درجة الحرارة ${current.temp_C}°C، الرطوبة ${current.humidity}%.\n`;
      }
      if (today) {
        const avgC = today.avgtempC;
        message += `متوسط درجة الحرارة لليوم: ${avgC}°C.\n`;
        // نصيحة الملابس
        if (parseInt(avgC) >= 20) {
          message += 'ننصح بارتداء ملابس خفيفة وجلب قبعة واقية من الشمس.';
        } else if (parseInt(avgC) >= 10) {
          message += 'ننصح بارتداء طبقات خفيفة ومعطف خفيف لبرودة الصباح والمساء.';
        } else {
          message += 'ننصح بارتداء ملابس دافئة وقفازات وقبعة للحماية من البرد.';
        }
      }
      resultDiv.textContent = message;
    })
    .catch((err) => {
      console.error('خطأ في جلب الطقس:', err);
      resultDiv.textContent = 'تعذر جلب حالة الطقس. حاول مجدداً.';
    });
}

/**
 * إعداد واجهة المساعد الذكي
 */
function initAssistant() {
  const chatBox = document.getElementById('chat-box');
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  if (!chatBox || !chatForm) return;
  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const question = chatInput.value.trim();
    if (!question) return;
    appendChat('user', question);
    chatInput.value = '';
    // معالجة السؤال والإجابة
    handleAssistantQuestion(question);
  });
}

/**
 * إضافة رسالة إلى صندوق الدردشة
 */
function appendChat(type, text) {
  const chatBox = document.getElementById('chat-box');
  const msgDiv = document.createElement('div');
  msgDiv.className = `chat-message ${type}`;
  msgDiv.textContent = text;
  chatBox.appendChild(msgDiv);
  // التمرير إلى الأسفل
  chatBox.scrollTop = chatBox.scrollHeight;
}

/**
 * معالجة أسئلة المساعد الذكي
 */
function handleAssistantQuestion(question) {
  // تحويل السؤال إلى أحرف صغيرة للمطابقة
  const q = question.toLowerCase();
  // إذا سأل عن برنامج اليوم أو تاريخ محدد
  const dateMatch = q.match(/(\d{1,2})\.(\d{1,2})/);
  if (q.includes('اليوم')) {
    // استخدم تاريخ اليوم المحلي
    const now = new Date();
    const d = now.getDate();
    const m = now.getMonth() + 1;
    replyWithProgram(d + '.' + m);
    return;
  } else if (dateMatch) {
    replyWithProgram(dateMatch[0]);
    return;
  }
  // سؤال عن الطقس
  if (q.includes('طقس') || q.includes('الطقس')) {
    // محاولة استخراج اسم المدينة من السؤال
    const words = question.split(/\s+/);
    let city = null;
    words.forEach((w) => {
      // إزالة الحروف غير الأبجدية/الارقام
      const clean = w.replace(/[^A-Za-zא-ת]/g, '');
      if (clean.length > 2) city = clean;
    });
    if (city) {
      fetch(`https://wttr.in/${encodeURIComponent(city)}?format=3`)
        .then((res) => res.text())
        .then((txt) => {
          appendChat('bot', `حالة الطقس في ${city}: ${txt}`);
        })
        .catch(() => {
          appendChat('bot', 'لم أستطع الحصول على حالة الطقس حالياً.');
        });
    } else {
      appendChat('bot', 'يرجى تحديد اسم المدينة لمعرفة حالة الطقس.');
    }
    return;
  }
  // البحث عن كلمة مفتاح في البرنامج
  const found = scheduleData.find((entry) => q.includes(entry.date) || q.includes(entry.title.toLowerCase()));
  if (found) {
    appendChat('bot', `برنامج يوم ${formatDateDisplay(found.date)}: ${found.title}. لمزيد من التفاصيل يمكنك الاطلاع على قسم البرنامج.`);
    return;
  }
  // إذا لم يتم التعرف على السؤال، سنفتح بحث عبر الويب في علامة تبويب جديدة
  // ونخبر المستخدم بما قمنا به.
  const query = encodeURIComponent(question);
  const searchUrl = `https://www.google.com/search?q=${query}`;
  // فتح نتائج البحث في نافذة جديدة
  window.open(searchUrl, '_blank');
  appendChat('bot', 'لم أستطع الإجابة مباشرة، لذا فتحت لك صفحة بحث على الويب في علامة تبويب جديدة.');
}